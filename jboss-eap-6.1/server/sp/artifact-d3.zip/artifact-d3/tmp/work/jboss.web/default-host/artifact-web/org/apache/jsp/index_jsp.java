package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.tomcat.InstanceManager _jsp_instancemanager;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_instancemanager = org.apache.jasper.runtime.InstanceManagerFactory.getInstanceManager(getServletConfig());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      response.addHeader("X-Powered-By", "JSP/2.2");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<html ng-app=\"app\">\r\n");
      out.write("<head>\r\n");
      out.write("<meta charset=\"utf-8\">\r\n");
      out.write("<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n");
      out.write("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n");
      out.write("<meta name=\"description\" content=\"\">\r\n");
      out.write("<meta name=\"author\" content=\"\">\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<meta content=\"initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no,width=device-width\" name=\"viewport\">\r\n");
      out.write("\t<!-- CSS -->\r\n");
      out.write("\r\n");
      out.write("\t<link rel=\"stylesheet\" href=\"vendor/bootstrap-datepicker.min.css\">\r\n");
      out.write("\t<link rel=\"stylesheet\" href=\"css/font-awesome.min.css\">\r\n");
      out.write("\t<link rel=\"stylesheet\" href=\"css/artifact.css\">\r\n");
      out.write("\t\r\n");
      out.write("\t<!-- JAVASCRIPT LIBRAIRIES -->\r\n");
      out.write("\t\r\n");
      out.write("\t<script src=\"components/angular/angular.js\"></script>\r\n");
      out.write("\t<script\tsrc=\"components/angular-ui-router/release/angular-ui-router.min.js\"></script>\r\n");
      out.write("\t<script src=\"components/angular-messages/angular-messages.min.js\"></script>\r\n");
      out.write("\t<script src=\"components/angular-file-upload/dist/angular-file-upload.min.js\"></script>\r\n");
      out.write("\t<script src=\"components/lodash-compat/lodash.min.js\"></script>\r\n");
      out.write("\t<script src=\"vendor/jquery-2.1.4.js\" type=\"text/javascript\"></script>\r\n");
      out.write("\t<script src=\"vendor/bootstrap.js\" type=\"text/javascript\"></script>\r\n");
      out.write("\t<script src=\"vendor/bootstrap-datepicker.js\" type=\"text/javascript\"></script>\r\n");
      out.write("\t<script src=\"vendor/bootstrap-datepicker.fr.js\" type=\"text/javascript\"></script>\r\n");
      out.write("\r\n");
      out.write("\t<!-- APPLICATION  -->\r\n");
      out.write("\t<script src=\"src/private/app.js\"></script>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\t<!-- ================ SHARED  ===================== -->\r\n");
      out.write("\r\n");
      out.write("\t<script src=\"src/private/shared/shared.module.js\"></script>\r\n");
      out.write("\t<script src=\"src/private/shared/shared.controller.js\"></script>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\t<!-- ================ FONCTIONS  ====================== -->\r\n");
      out.write("\r\n");
      out.write("\t<script src=\"src/private/fonction/fonction.module.js\"></script>\r\n");
      out.write("\t<script src=\"src/private/fonction/fonction.service.js\"></script>\r\n");
      out.write("\t<script src=\"src/private/fonction/fonction.controller.js\"></script>\r\n");
      out.write("\t\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("</head>\r\n");
      out.write("\r\n");
      out.write("<body>\r\n");
      out.write("\t<div ui-view></div>\r\n");
      out.write("</body>\r\n");
      out.write("\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
